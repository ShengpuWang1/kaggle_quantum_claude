# 33 | QCC V9 members: the 18 files of submission sub_020c

Inputs of the busyaprime notebook for the Google Quantum AI Verifiable Quantum Circuit Compilation competition. These
are the 18 files of our submission `sub_020c` (SHA-256 of the zip `75602670...`), byte for byte. Sub-folders are
flattened: `dfthcsos__angle_k_0.kmb` is `dfthcsos/angle_k_0.kmb` in the zip. The notebook finds each file by name,
accepts it only by its SHA-256 (`SHA256SUMS`), and writes the zip again.

`sub_020c` is avazaku's public output of 2026-10-28 19:24 UTC (zip `b93803b4...`) with one file of ours in place
of the one it carried: `invsqrt.kmb`. His zip is heliosli's public output of 15:57 UTC (zip `e63491b5...`) with
his own weights file `dfthcsos/submission.npz`; both carried our earlier fusion file (`07314803...`, version 4 of
this dataset), and this version holds its successor. Our run of the hosts' metric code on `sub_020c`: Public
22.724320, Private 22.689636
(our salts).

| file here | path in submission.zip | bytes | SHA-256 | author | licence |
|---|---|---:|---|---|---|
| `dfthcsos__submission.npz` | `dfthcsos/submission.npz` | 1,995,396 | `f984ba30...` | avazaku: his weights for the SomeJoint team's R8 B143 C60 full-XOR words on heliosli's circuits (a gauge and proximal-offset refit of their weights), from his public output, unchanged | Apache 2.0 as his notebook's text states; the page's licence line not read by us |
| `dqi.kmb` | `dqi.kmb` | 505,139,960 | `4ee7a17b...` | heliosli: his 889-qubit narrowing of the SomeJoint team's 897-qubit decoder, unchanged | Apache 2.0 (his release dataset) over SomeJoint's Apache-2.0 source |
| `invsqrt.kmb` | `invsqrt.kmb` | 450,013 | `9a8627c8...` | **busyaprime** (Akmal Xodarev): mrmeows' 63-qubit file with two regions re-synthesised by us (the main lookup, then window S1) | Apache 2.0 |
| `dfthcsos__angle_k_0.kmb` to `dfthcsos__angle_k_14.kmb` | `dfthcsos/angle_k_0.kmb to dfthcsos/angle_k_14.kmb` | about 0.35 to 0.40 MB each | 15 files, see `SHA256SUMS` | heliosli: his 15 angle circuits for the SomeJoint team's words, unchanged | Apache 2.0 on his notebook page (read 2026-10-27 at version 7, under its earlier slug); the page of the version that wrote them not read by us; not in his release dataset |

## What is ours

- `invsqrt.kmb`: mrmeows' 63-qubit file with two regions re-synthesised by our searches. Step 1 (version 4, file
  `07314803...`): the main lookup, -1.156% on the fusion bill against his file. Step 2 (this version):
  the six product blocks of window S1, 25 AND gates in place of
  30, the same output tables, everything outside the window byte-identical. Our verifier,
  6 runs (unsalted plus 5 salts), all PASS at Q 63: cost
  102,349.21 to 102,349.25 (unsalted
  102,349.24), against 102,664.24 for step 1: -0.3068%. The official verifier on
  x86-64, two salts: PASS 102,349.21, PASS 102,349.21. Our run of the hosts' metric code on
  this zip (Public split, our salt): 102,349.22.
- Nothing else in this version is ours. Our chemistry of 2026-10-28 is measured and dominated by the chemistry here:
  our loader relations (heliosli's method, our search) on the SomeJoint team's earlier full-XOR chemistry,
  343,495,564.58 (-0.4719% on it), and on their newer one, 343,004,823.75
  (-0.0489% on it); heliosli's circuits for the same words cost 341,914,455.08, and with
  avazaku's weights 341,880,855.44 (-0.0098% on heliosli's).

## Credits

- **heliosli**: `dqi.kmb` (the SomeJoint team's 897-qubit decoder "modified by heliosli", at
  889 qubits) and the 15 chemistry angle circuits, unchanged, from the output of his notebook
  [The dataset is now public now. Enjoy!](https://www.kaggle.com/code/heliosli/the-dataset-is-now-public-now-enjoy) (run 2026-10-28 15:57 UTC, zip `e63491b5...`) and his release
  dataset [qcc-circuits-live](https://www.kaggle.com/datasets/heliosli/qcc-circuits-live) (Apache 2.0). His dataset's CREDITS.md (read 2026-10-28 07:51 UTC) names the
  decoder's lineage: the SomeJoint team's Apache-2.0 source for the 897-qubit decoder with GPT-6 Astra Pro's 658-Toffoli
  jet; Ahmed Berat Ozer; Alex Chilton's 883-qubit Schur decoder, based on jday96314's QuantumAI decoder; mrmeows, Ahmed
  Berat Ozer and manwithacat (mask projection); Dmitrii Gluzdov, Agniv Banerjee (SomeJoint), ViberTeam, Phuc Thai
  (DePie). His chemistry: official x86-64 cost 341,914,455.08, lambda_eff 48.764252, T
  16,306 (4,188 loader Toffolis per pass), Q 430. Licences: his
  release dataset (Apache 2.0) holds `dqi.kmb`; the 15 angle circuits come from his notebook's output, whose page we
  read as Apache 2.0 on 2026-10-27 (version 7, under its earlier slug); the page of the version that wrote them was not
  read by us.
- **avazaku**: `dfthcsos/submission.npz`, unchanged, from the output of his notebook
  [Gauge-Prox + Sign-Copy QROM](https://www.kaggle.com/code/avazaku/gauge-prox-sign-copy-qrom) (run 2026-10-28 19:24 UTC, zip `b93803b4...`): his weights for the
  SomeJoint team's words on heliosli's circuits, a gauge and proximal-offset refit of their weights (his arm
  "Alternating continuation", started from his earlier Iso-Gap coefficients). Same circuits and stamps as heliosli's zip;
  official x86-64 cost 341,880,855.44, lambda_eff 48.759460 (heliosli's zip:
  48.764252), error_1 19.9995 mHa, both salts we ran equal. Licence:
  his notebook's text states "New study code is Apache 2.0. Retain upstream licenses and attribution." (source read 2026-10-28 21:05 UTC); his checkpoint
  dataset [gauge-prox-numerical-checkpoints](https://www.kaggle.com/datasets/avazaku/gauge-prox-numerical-checkpoints) is apache-2.0 on its metadata; the page's licence line was not read by
  us. His notebook credits the upstream lineage, busyaprime among it.
- **Agniv Banerjee and the SomeJoint team**: the chemistry words (R8 B143 C60 full-XOR) and the weights avazaku's file
  refits ("our team's final R8 B143 C60 factorization with five coded deltas and full-XOR five-word angle lookups", as their output names it; their weights file is not in this version);
  5 of the 15 angle circuits are byte-equal to theirs; and the 897-qubit decoder heliosli narrowed. Their notebooks: [quantum-circuits-22-67-local-gm-full-xor-chem](https://www.kaggle.com/code/somejoint/quantum-circuits-22-67-local-gm-full-xor-chem)
  (their run of `dqi.kmb`, empty salt: PASS, Q 889, mean T 440,563.96,
  0 failed shots) and [quantum-circuits-22-34-local-gm-897-qubit-dqi](https://www.kaggle.com/code/somejoint/quantum-circuits-22-34-local-gm-897-qubit-dqi). Our run of
  the hosts' metric code on this zip (our Public-split salt): `dqi.kmb` cost 4.14781e+11.
- **mrmeows** (team selenium): the 63-qubit fusion circuit and its lookup and block design, the base of our
  `invsqrt.kmb`, from [qcc-1375-open-circuits](https://www.kaggle.com/datasets/mrmeows/qcc-1375-open-circuits), Apache 2.0. His credit line for the fusion circuits: Akmal
  Xodarev (busyaprime), Phuc Thai (DePie), Dmitrii Gluzdov, marsyas.
- **Ahmed Berat Ozer**: the quantization and lambda loop in the chemistry line, and his narrowing work in the decoder
  line, from [Quantum AI - DF-THC Group Compression](https://www.kaggle.com/code/ahmedberatozer/quantum-ai-df-thc-group-compression), Apache 2.0.
- **manwithacat**: mask projection in the decoder line (as the lineage above names it).
- **Evgen Dvorkin (evgendvorkin)**: the zip layout of our version 2 (history).
- **Google Quantum AI** (the hosts): the verifiers and kickmix that check these files, competition data.

Licences: our file is Apache 2.0 (`LICENSE`, `NOTICE.md`); each author keeps their copyright. heliosli's `dqi.kmb`
is Apache 2.0 as his release dataset states; his angle circuits as his notebook page read on 2026-10-27; avazaku's
weights as his notebook's text states. The decoder design traces to a repository that, as heliosli's licence file
says, states no licence: only the compiled circuit, as already published in public Kaggle outputs, is included here.
