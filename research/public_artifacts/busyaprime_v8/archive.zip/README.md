# 33 | QCC V8 members: the 18 files of submission sub_015

Inputs of the busyaprime notebook for the Google Quantum AI Verifiable Quantum Circuit Compilation competition. These
are the 18 files of our submission `sub_015` (SHA-256 of the zip `aa1f4689...`), byte for byte. Sub-folders are
flattened: `dfthcsos__angle_k_0.kmb` is `dfthcsos/angle_k_0.kmb` in the zip. The notebook finds each file by name,
accepts it only by its SHA-256 (`SHA256SUMS`), and writes the zip again.

`sub_015` is the SomeJoint team's public output (zip `1105faa6...`) with one file of ours in place of
theirs: `invsqrt.kmb`. Their zip holds their 897-qubit decoder and heliosli's chemistry, byte for byte as in
heliosli's own output (zip `e97548f8...`). Our run of the hosts' metric code on `sub_015`: Public
22.402947, Private 22.402948
(our salts).

| file here | path in submission.zip | bytes | SHA-256 | author | licence |
|---|---|---:|---|---|---|
| `dfthcsos__submission.npz` | `dfthcsos/submission.npz` | 2,885,708 | `5d014b2e...` | heliosli: his refit of the weights at Ahmed Berat Ozer's V9 words, unchanged | Apache 2.0 (his release dataset) |
| `dqi.kmb` | `dqi.kmb` | 505,134,467 | `b3354f60...` | Agniv Banerjee and the SomeJoint team: their 897-qubit decoder, unchanged | Apache 2.0 on its page at version 12 (read 2026-10-27, 16:19 to 16:40 UTC, under an earlier title); the page of the version that wrote this file not read by us |
| `invsqrt.kmb` | `invsqrt.kmb` | 451,423 | `07314803...` | **busyaprime** (Akmal Xodarev): mrmeows' 63-qubit file with its main lookup re-synthesised by us | Apache 2.0 |
| `dfthcsos__angle_k_0.kmb` to `dfthcsos__angle_k_14.kmb` | `dfthcsos/angle_k_0.kmb to dfthcsos/angle_k_14.kmb` | about 0.44 MB each | 15 files, see `SHA256SUMS` | heliosli: his J5 build of Ahmed Berat Ozer's V9 angle words, unchanged | Apache 2.0 (his release dataset) |

## What is ours

- `invsqrt.kmb`: mrmeows' 63-qubit file (SHA-256 `0766a111...`) with its main lookup
  (35 outputs of the 8-bit address) re-synthesised by our pool-capped search:
  172 AND gates in place of the author's 186, the same 40-wire pool, the same output wires and tables;
  everything outside that region is byte-identical. Our verifier, 6 runs (unsalted plus
  5 salts), all PASS at Q 63: cost
  102,664.16 to 102,664.28 (unsalted
  102,664.24), against 103,546.23 for the base file: -0.852%. The official verifier on
  x86-64, unsalted: PASS, cost 102,664.24. Our run of the hosts' metric code on this zip
  (Public split, our salt): 102,664.20.
- Nothing else in this version is ours. Versions 2 and 3 held our chemistry weights (a refit plus a column gauge at
  Ahmed Berat Ozer's V9 words; official x86-64 cost 355,065,066.08, lambda_eff 47.537037) and, in
  version 3, our loader plans for his J5 circuits (4,812 to 4,758 loader Toffolis per pass, T
  17,330 to 17,222, cost 352,852,312.06). On the loader, heliosli published the method, a searched relation layout with an exact GF(2) check (his notebook text; his code is not public); our own implementation of it found plans with more relations for Ahmed Berat Ozer's unchanged words.
- heliosli's chemistry in this version beats both: official x86-64 cost 349,339,717.33, lambda_eff
  47.494022, T 17,066 (4,680 loader Toffolis per pass), Q
  431, error_1 19.99900 mHa and error_2
  19.99893 mHa (limit 20 mHa each): -0.9955% against our weights and loader,
  -1.6125% against our weights on Ahmed Berat Ozer's circuits, -1.6462% against his V9 chemistry
  (355,186,805.37).

## Credits

- **heliosli**: the 15 chemistry angle circuits and `submission.npz`, unchanged, from the output of his notebook
  [The dataset is now public now. Enjoy!](https://www.kaggle.com/code/heliosli/the-dataset-is-now-public-now-enjoy) (zip `e97548f8...`; his log: "geometric mean of reference /
  cost: 22.1291" on his salt) and his release dataset [qcc-circuits-live](https://www.kaggle.com/datasets/heliosli/qcc-circuits-live) (Apache 2.0). In his words, his part
  is the J = 5 angle compiler (multi-phase low cache, word-top-bit scratch, a searched relation layout) and a refit of
  W and H2_I with every word held fixed. His chemistry credits, as his notebook gives them: Ahmed Berat Ozer's V9 table
  (Michael Rustad's R = 10, B = 129, C = 46 factorization with Ahmed Berat Ozer's quantization and lambda loop),
  mrmeows' compiler foundations and one-body tool, kozykappa's joint refine, marculera's four-address loaders,
  Vladislav Lavrentev / lightningv08's five-word schedule, and Michael Rustad's Apache-2.0 metric and gauge code.
- **Agniv Banerjee and the SomeJoint team**: `dqi.kmb`, their 897-qubit decoder ("GPT-6 Astra Pro's 897-qubit decoder with the 658-Toffoli jet", as
  their output names it), unchanged, and the zip this one is made from (zip `1105faa6...`: its order, stamps
  and the 17 members we keep; their run, empty salt: PASS, Q 897, mean T 440,633.00,
  0 failed shots, cost 4.22346e+11; geometric mean
  22.339159 on their salt). Their notebook: [quantum-circuits-22-34-local-gm-897-qubit-dqi](https://www.kaggle.com/code/somejoint/quantum-circuits-22-34-local-gm-897-qubit-dqi) (its current
  version). Our run of the hosts' metric code on this zip (our Public-split salt): cost 4.22346e+11.
  Their earlier 883-qubit decoder (zip `be8301da...`) was in version 3 of this dataset.
- **mrmeows** (team selenium): the 63-qubit fusion circuit and its lookup design, the base of our `invsqrt.kmb`, from
  [qcc-1375-open-circuits](https://www.kaggle.com/datasets/mrmeows/qcc-1375-open-circuits), Apache 2.0. His credit line for the fusion circuits: Akmal Xodarev (busyaprime),
  Phuc Thai (DePie), Dmitrii Gluzdov, marsyas.
- **Ahmed Berat Ozer**: the V9 angle words, quantization and lambda loop in heliosli's circuits, and the J5 compiler
  that emitted our earlier loader plans (version 3), from [Quantum AI - DF-THC Group Compression](https://www.kaggle.com/code/ahmedberatozer/quantum-ai-df-thc-group-compression) version 9
  and [vqcc-v9-components](https://www.kaggle.com/datasets/ahmedberatozer/vqcc-v9-components) version 1, Apache 2.0.
- **Google Quantum AI** (the hosts): the verifiers and kickmix that check these files, competition data.

Licences: our file is Apache 2.0 (`LICENSE`, `NOTICE.md`); each author keeps their copyright. heliosli's files are
Apache 2.0 as his release dataset states; `dqi.kmb` is SomeJoint's file as their public output publishes it, under the
licence on their notebook page.
