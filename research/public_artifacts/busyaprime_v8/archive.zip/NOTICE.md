# NOTICE

This dataset redistributes files by other authors, unchanged, and one file of ours modified from Apache-2.0 work.

- `invsqrt.kmb`: Copyright 2026 Akmal Xodarev (busyaprime), Apache License 2.0. Modified from mrmeows' (team selenium)
  63-qubit `invsqrt.kmb` (https://www.kaggle.com/datasets/mrmeows/qcc-1375-open-circuits, Apache-2.0): the main lookup region is re-synthesised; the rest is his, unchanged.
- `dqi.kmb`: Agniv Banerjee and the SomeJoint team, output of their notebook (https://www.kaggle.com/code/somejoint/quantum-circuits-22-34-local-gm-897-qubit-dqi), 897 qubits. Unchanged.
  The order of the zip, its stamps and the 17 members we keep are their output's.
  Licence: Apache 2.0 on its page at version 12 (read 2026-10-27, 16:19 to 16:40 UTC, under an earlier title); the page of the version that wrote this file not read by us.
- `dfthcsos__angle_k_0.kmb` to `dfthcsos__angle_k_14.kmb` and `dfthcsos__submission.npz`: heliosli, output of
  https://www.kaggle.com/code/heliosli/the-dataset-is-now-public-now-enjoy, from his release dataset https://www.kaggle.com/datasets/heliosli/qcc-circuits-live (Apache-2.0), byte-equal in SomeJoint's output. Unchanged. The angle words are Ahmed Berat Ozer's V9
  (https://www.kaggle.com/code/ahmedberatozer/quantum-ai-df-thc-group-compression, Apache-2.0).

The full licence text is in `LICENSE`.
